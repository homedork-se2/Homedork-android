package com.example.homedork.api.model.device;

public class Thermometer extends Device{

    public Thermometer(){

    }
}
