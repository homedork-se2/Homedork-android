package com.example.homedork.api.model.device;

public enum DeviceType {
    LAMP, FAN, CURTAIN, THERM
}