package com.example.homedork.signup;


public class User {

    public String fullName, email;

    public User() {

    }

    public User(String fullNamel, String email) {

        this.fullName = fullNamel;
        this.email = email;

    }
}