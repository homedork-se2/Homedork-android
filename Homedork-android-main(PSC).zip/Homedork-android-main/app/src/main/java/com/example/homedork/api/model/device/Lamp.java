package com.example.homedork.api.model.device;

public class Lamp extends Device {


    public Lamp() {
    }

}
