package com.example.homedork.api.model.device;

public enum State {
    OFF, ON
}
