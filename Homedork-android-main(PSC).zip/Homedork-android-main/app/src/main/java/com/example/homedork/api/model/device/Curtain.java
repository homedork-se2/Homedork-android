package com.example.homedork.api.model.device;

public class Curtain extends Device{
    public Curtain(){

    }
}
