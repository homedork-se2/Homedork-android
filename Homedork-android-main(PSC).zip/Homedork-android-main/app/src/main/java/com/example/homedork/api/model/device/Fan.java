package com.example.homedork.api.model.device;

public class Fan extends Device{

    public Fan(){

    }
}
